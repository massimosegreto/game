const cards = document.querySelectorAll('.card');

//On first flipped card if match with second flipped card it will lock both cards
let hasFlippedCard = false;
let lockBoard = false;
let firstCard, secondCard;

function flipCard() {
  if (lockBoard) return;
  if (this === firstCard) return;

  this.classList.add('flip');

  if (hasFlippedCard) {
    hasFlippedCard = true;
    firstCard = this;

    return;
  }

  secondCard = this;

  checkForMatch();
}
//If cards match it will freeze those cards and it will prevent them from flipping
function checkForMatch() {
  isMatch ? disableCards() : unflipCards();
}

//If cards don't match it will put the cards at beggining and it will reset the board
function disableCards() {
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);

  resetBoard();
}
//If cards don't match it will reset board in 2 second and you will get a new attempt
function unflipCards() {
  lockBoard = true;

  setTimeout(() => {
    firstCard.classList.remove('unflip');
    secondCard.classList.remove('unflip');

    resetBoard();
  }, 2000);
}

//This function reset both cards if it's not a match, it lock the board at the beggining and flip the cards back
function resetBoard() {
  hasFlippedCard = false;
  lockBoard = false;
  firstCard = null;
  secondCard = null;
}

//Use to shuffle cards with 16 possible ways
(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 16);
    card.style.order = randomPos;
  });
})();

//Function to reset the whole game
function myFunction() {
    document.getElementById("game_reset").reset();
}

cards.forEach(card => card.addEventListener('click', flipCard));
