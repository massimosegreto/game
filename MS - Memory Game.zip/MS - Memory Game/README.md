Html - Has 8 parts, each part represent one card with both sides. One of the card is set to be always first card.

Css - Is written very simple with basic styles.

Js - Has notes to explain each function.
